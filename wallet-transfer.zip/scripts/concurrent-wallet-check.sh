#!/usr/bin/env bash
set -euo pipefail

# Usage: ./scripts/concurrent-wallet-check.sh <bearer-token> [request-count] [api-url]
# Example: ./scripts/concurrent-wallet-check.sh alice-token 100 http://localhost:8080

TOKEN="${1:?Bearer token is required}"
REQUEST_COUNT="${2:-25}"
API_URL="${3:-http://localhost:8080}"

if ! [[ "$REQUEST_COUNT" =~ ^[1-9][0-9]*$ ]]; then
  echo "request-count must be a positive integer" >&2
  exit 2
fi

for command in curl jq xargs; do
  command -v "$command" >/dev/null || { echo "Missing required command: $command" >&2; exit 2; }
done

WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT
AUTH_HEADER="Authorization: Bearer $TOKEN"

echo "Creating (or finding) the caller's wallet..."
FIRST_RESPONSE="$(curl --fail-with-body --silent --show-error --request POST "$API_URL/wallets" --header "$AUTH_HEADER")"
WALLET_ID="$(jq -er '.id' <<<"$FIRST_RESPONSE")"
echo "Expected wallet ID: $WALLET_ID"

export API_URL AUTH_HEADER WORK_DIR
seq "$REQUEST_COUNT" | xargs -P "$REQUEST_COUNT" -n 1 -I {} sh -c '
  curl --fail-with-body --silent --show-error --request POST "$API_URL/wallets" \
    --header "$AUTH_HEADER" > "$WORK_DIR/{}.json"
'

SUCCESSFUL="$(find "$WORK_DIR" -name '*.json' -type f | wc -l | tr -d ' ')"
UNIQUE_IDS="$(jq -r '.id' "$WORK_DIR"/*.json | sort -u)"
UNIQUE_COUNT="$(printf '%s\n' "$UNIQUE_IDS" | sed '/^$/d' | wc -l | tr -d ' ')"

if [[ "$SUCCESSFUL" != "$REQUEST_COUNT" || "$UNIQUE_COUNT" != "1" || "$UNIQUE_IDS" != "$WALLET_ID" ]]; then
  echo "FAIL: expected $REQUEST_COUNT responses for $WALLET_ID; received $SUCCESSFUL responses and $UNIQUE_COUNT wallet IDs." >&2
  printf 'Returned IDs:\n%s\n' "$UNIQUE_IDS" >&2
  exit 1
fi

echo "PASS: all $REQUEST_COUNT concurrent get-or-create calls returned wallet $WALLET_ID."
